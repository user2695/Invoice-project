# Mind map

I used nodejs library because i believe i am most comfortable with nodejs for backend.

For front-end i used ejs. I have also used MVC design pattern so that it can be easy to read and debug.

I liked to part where i had to create the pdf for hard coded data. But i am facing problems with sending it to email.

Error:
code: 'EAUTH',

response: '535-5.7.8 Username and Password not accepted.

Learn more at\n' +
'535 5.7.8 https://support.google.com/mail/?p=BadCredentials c17-20020a170903235100b0019e76a99cdbsm10909897plh.243 - gsmtp',

responseCode: 535,

command: 'AUTH PLAIN'
